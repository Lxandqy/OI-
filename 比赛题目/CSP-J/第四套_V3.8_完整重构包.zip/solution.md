# T1 接龙（chain）

---

## 先限制每张牌最多能得多少分

---

收牌需要两个相同数字作端点，所以只有出现至少两次的数字能成为一次收牌的得分系数。记其中最大的为 $x$。

任何一次收牌的端点数字都不超过 $x$，每张牌又至多被收一次，因此全部得分不超过 $xn$。这个上界可以达到：把两张 $x$ 放在最前和最后，其余牌放在中间，前面一直不收牌，最后一次把全部 $n$ 张一起收走，恰好得到 $xn$。

用频次数组统计数字，找到出现至少两次的最大值即可。若没有重复数字，任何收牌都不合法，答案为 $0$，也包含 $n=1$ 的情况。

设值域上界 $V=10^5$，读入统计 $O(n)$，计数数组的初始化计入 $O(V)$，总时间 $O(n+V)$、空间 $O(V)$。答案至多 $10^{10}$，乘法使用 `long long`。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

const int maxv = 100000 + 10;
int cnt[maxv];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int n;
	cin >> n;
	int best = 0;
	for(int i = 1; i <= n; i++){
		int x;
		cin >> x;
		cnt[x]++;
		if(cnt[x] >= 2){
			best = max(best, x);
		}
	}

	cout << 1LL * best * n << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分，以下点组独立计分。满分统计已足够简单，各档复用同一份代码。

| 条件 | 点号与分值 | 做法与复杂度 |
|---|---|---|
| $n\le100$ | $1\sim2$，$20$ 分 | 统计重复数字的最大值，再乘 $n$；时间 $O(n+V)$、空间 $O(V)$。 |
| 所有数字相同 | $3\sim4$，$20$ 分 | $n\ge2$ 时该数字就是最大重复值，全部一次收走；$n=1$ 时无重复，得 $0$。仍由频次程序处理。 |
| $a_i\le1000$ | $5\sim7$，$30$ 分 | 同样统计重复最大值，值域缩小不改变结论；交付程序仍使用完整值域数组。 |
| 完整范围 | $8\sim10$，$30$ 分 | 上界 $xn$ 与一次收完的构造均成立，时间 $O(n+V)$、空间 $O(V)$。 |

# T2 平方和（sumsq）

---

## 平方余数互补，只保留组内最大的两个数

---

两个位置能否配对，只取决于它们的平方模 $k$ 的余数。若 $a_i^2\bmod k=r$，另一数的平方余数必须为

$$q=(k-r)\bmod k.$$

所以按平方余数分组。余数组不同，两边各取最大的原数，平方和最大；余数组相同，则要取本组最大的两个不同位置。因为所有原数都是正数，原数越大，平方也越大，每组其余候选都不会改进答案。

代码用有序映射 `best` 为实际出现的余数保存前两大值。新数大于已有最大值时，将旧最大值移到第二位；否则只尝试更新第二位。相同数值出现在两个位置时也分别保留，保证同组配对合法。初始化的 $0$ 表示尚无候选，因为输入均为正数。

遍历每个出现的余数 $r$，查找互补组 $q$，按是否同组计算平方和并取最大值。不同组的配对可能被检查两次，但这里只求最大值，不影响结果。输入保证有合法对。

至多 $n$ 个余数组，插入和查找各为 $O(\log n)$，总时间 $O(n\log n)$、空间 $O(n)$。最大平方和为 $2\times10^{18}$，先将数读入 `long long` 再相乘。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

map<long long,pair<long long,long long> > best;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int n;
	long long k;
	cin >> n >> k;
	for(int i = 1; i <= n; i++){
		long long x;
		cin >> x;
		long long r = x * x % k;
		pair<long long,long long> &p = best[r];
		if(x > p.first){
			p.second = p.first;
			p.first = x;
		}else if(x > p.second){
			p.second = x;
		}
	}

	long long ans = 0;
	for(map<long long,pair<long long,long long> >::iterator it = best.begin(); it != best.end(); it++){
		long long r = it->first;
		long long other = (k - r) % k;
		map<long long,pair<long long,long long> >::iterator jt = best.find(other);
		if(jt == best.end()) continue;
		long long x = it->second.first;
		long long y = jt->second.first;
		if(r == other) y = it->second.second;
		if(y > 0) ans = max(ans,x * x + y * y);
	}
	cout << ans << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分，前两个点组独立计分，不能把两个程序各自的保证分直接当作单个程序得分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n\le2000$ | $1\sim2$，$20$ 分 | 枚举不同位置 $i<j$，检查平方和能否被 $k$ 整除并取最大值。时间 $O(n^2)$，空间 $O(n)$。 |
| 2 | $k\le10^5$ | $3\sim5$，$30$ 分 | 用余数数组代替映射，每组仍保留最大的两个不同位置，再枚举互补余数。此分支时间 $O(n+k)$；代码还保存原数组并固定开 $10^5+10$ 个桶，空间 $O(n+10^5)$。 |
| — | 完整范围 | $6\sim10$，$50$ 分 | 用有序映射只保存出现的余数，时间 $O(n\log n)$，空间 $O(n)$。 |

第 2 份源码在 $k>10^5$ 时转用成对枚举，因此也覆盖 $n\le2000$，联合保证前五点共 $50$ 分；大 $n$、大 $k$ 时不保证时限。

# T3 彩彩的三彩项链（necklace）

---

## 固定首色，逐颗记录末色

---

相邻珠子必须异色。一旦确定第一颗的目标颜色，向后处理时只需知道上一颗的目标色；最后再检查末色与首色是否不同。因此枚举首色 $first$ 的三种选择，分别计算最少代价。

把红、绿、蓝编号为 $0,1,2$。原色为 $x$，改成 $c$ 所需的最少点击数是

$$w(x,c)=(c-x+3)\bmod3.$$

多点整整一圈不会改变颜色，只会增加代价，所以每颗最多需要点击两次。

固定首色后，令 $f_i[c]$ 表示前 $i$ 颗已经改好、彼此相邻异色，且第 $i$ 颗目标色为 $c$ 的最少代价。后续合法颜色只受 $c$ 和固定首色影响，同一状态保留最小代价即可。

第 $i$ 颗取色 $c$，上一颗只能取 $p\ne c$，故

$$f_i[c]=\min_{p\ne c}f_{i-1}[p]+w(s_i,c).$$

初始化时仅 $f_1[first]=w(s_1,first)$ 可达，其他末色为无穷大。处理完后，只从 $c\ne first$ 的状态中取答案，再比较三种首色。每个合法环形染色都有唯一首色，并按相邻异色的转移被覆盖。

代码用 `dp` 保存上一颗的三个状态，用 `next` 单独计算新状态，避免同一颗被重复使用；求完再覆盖。时间 $O(n)$，DP 额外空间 $O(1)$；完整实现保存输入字符串，总空间 $O(n)$。最少代价至多 $2n$，使用 `int` 足够。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

int color(char c){
	if(c == 'r') return 0;
	if(c == 'g') return 1;
	return 2;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int n;
	string s;
	cin >> n >> s;
	const int INF = 1000000000;
	int ans = INF;
	for(int first = 0; first < 3; first++){
		int dp[3] = {INF,INF,INF};
		dp[first] = (first - color(s[0]) + 3) % 3;
		for(int i = 1; i < n; i++){
			int next[3] = {INF,INF,INF};
			for(int last = 0; last < 3; last++){
				for(int now = 0; now < 3; now++){
					if(last == now) continue;
					int cost = (now - color(s[i]) + 3) % 3;
					next[now] = min(next[now],dp[last] + cost);
				}
			}
			for(int c = 0; c < 3; c++) dp[c] = next[c];
		}
		for(int last = 0; last < 3; last++){
			if(last != first) ans = min(ans,dp[last]);
		}
	}
	cout << ans << '\n';
	return 0;
}
```

## 部分分

---

每点 $5$ 分，各点组独立计分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n=10$ | $1\sim2$，$10$ 分 | 枚举首色，依次搜索与前色不同的两种目标色，累加点击数；末色不同于首色时更新答案。时间 $O(2^n)$，保存输入与递归栈共 $O(n)$ 空间。 |
| — | $n=1000$ | $3\sim4$，$10$ 分 | 用正文三状态 DP，每颗比较不同前色，时间 $O(n)$、完整代码空间 $O(n)$。 |
| — | 原串只有一种颜色 | $5\sim6$，$10$ 分 | 目标仍可用三色，按同一 DP 分别比较每颗点击代价，时间 $O(n)$。 |
| — | 原串只有两种颜色 | $7\sim8$，$10$ 分 | 不能将目标色也限制为两种；仍用三状态 DP，时间 $O(n)$。 |
| — | 无额外限制 | $9\sim20$，$60$ 分 | 枚举首色后检查末色，三状态 DP 覆盖一般环，时间 $O(n)$、完整代码空间 $O(n)$。 |

# T4 表达式（eval）

---

## 把连续的加法段括起来

---

每个数都是正整数，乘法中的因子至少为 $1$。若某个加号的一侧含乘法，可以作以下调整：

$$A+BC\le(A+B)C,\qquad AB+C\le A(B+C).$$

两式分别因为差值为 $A(C-1)$ 和 $C(A-1)$，均非负。数字和运算符的先后顺序没有改变。

从任意括号方案出发，只要一个加号的子表达式中还含乘号，就在相邻的加、乘节点处这样调整，将乘法提到加法上方。每次被调整的加号所包含的数字范围都会缩小，其余加号的范围不变，所以调整会结束，值始终不下降。最后每个加法段内部只剩加号，各段之间相乘。

因此最优方案就是把原串按乘号断开，先计算每个连续加法段的和，再把这些和相乘。例如 `2+3*4+5` 变为 $(2+3)(4+5)$。

## 逐位读数与高精度

---

单个输入数就可能超出机器整数，不能先用 `long long` 解析。代码以 $10^4$ 为基数，低位在前保存高精度数，维护当前数 `number`、当前加法段和 `sum`，以及已结束各段的乘积 `product`：

- 遇到数字，令 `number` 乘 $10$ 再加当前数字。
- 遇到加号，将 `number` 加入 `sum`，清空当前数。
- 遇到乘号，先把当前数并入段和，再把段和乘入 `product`，清空当前数和段和。
- 扫描结束后，结算最后一个数和最后一个加法段。

`product` 初始为 $1$，空的高精度数组表示 $0$。加法按位进位，乘法采用竖式；输出最高位后，其余每个数组位补足四位。

设原串长为 $L$，最终答案有 $D$ 个十进制位。正整数的加法、乘法不会使结果小于任一输入数，因此处理中数值的位数不超过 $D$。逐位读数及加法总成本为 $O(LD)$。每个乘法因子的位数不超过该段原数的总位数，各因子位数之和不超过 $L$，故竖式乘法累计也为 $O(LD)$。总时间 $O(LD)$，保守上界 $O(L^2)$；代码保存原串和高精度数，空间 $O(L+D)$。这里 $D\le L\le5000$，不能把高精度运算当作常数时间。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

struct Big{
	static const int BASE = 10000;
	vector<int> d;
	Big(int x = 0){
		if(x > 0) d.push_back(x);
	}
	void addDigit(int x){
		int carry = x;
		for(int i = 0; i < (int)d.size(); i++){
			int value = d[i] * 10 + carry;
			d[i] = value % BASE;
			carry = value / BASE;
		}
		if(carry > 0) d.push_back(carry);
	}
	void add(const Big &b){
		if(d.size() < b.d.size()) d.resize(b.d.size(),0);
		int carry = 0;
		for(int i = 0; i < (int)d.size(); i++){
			int value = d[i] + carry;
			if(i < (int)b.d.size()) value += b.d[i];
			d[i] = value % BASE;
			carry = value / BASE;
		}
		if(carry > 0) d.push_back(carry);
	}
	Big multiply(const Big &b) const{
		Big result;
		if(d.empty() || b.d.empty()) return result;
		result.d.resize(d.size() + b.d.size() + 1,0);
		for(int i = 0; i < (int)d.size(); i++){
			long long carry = 0;
			for(int j = 0; j < (int)b.d.size() || carry > 0; j++){
				long long value = result.d[i + j] + carry;
				if(j < (int)b.d.size()) value += 1LL * d[i] * b.d[j];
				result.d[i + j] = value % BASE;
				carry = value / BASE;
			}
		}
		while(!result.d.empty() && result.d.back() == 0) result.d.pop_back();
		return result;
	}
	void print() const{
		if(d.empty()){
			cout << 0;
			return;
		}
		cout << d.back();
		for(int i = (int)d.size() - 2; i >= 0; i--){
			cout << setw(4) << setfill('0') << d[i];
		}
	}
};

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	string s;
	cin >> s;
	Big product(1),sum,number;
	for(int i = 0; i < (int)s.size(); i++){
		if(s[i] >= '0' && s[i] <= '9'){
			number.addDigit(s[i] - '0');
		}else if(s[i] == '+'){
			sum.add(number);
			number = Big();
		}else{
			sum.add(number);
			product = product.multiply(sum);
			sum = Big();
			number = Big();
		}
	}
	sum.add(number);
	product = product.multiply(sum);
	product.print();
	cout << '\n';
	return 0;
}
```

## 部分分

---

每点 $5$ 分；各行对应题面点组，表中分值为该组分值。

| 序号 | 条件 | 点号与分值 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $L\le10$ | $1\sim2$，$10$ 分 | 解析数字与运算符，在每个数字区间枚举最后运算的位置，递归求两侧最大值再按该运算符合并。正数使运算对两侧单调；若有 $q$ 个数，时间 $O(L+3^q)$，空间 $O(L+q)$。 |
| — | 所有数为 $1$ | $3\sim4$，$10$ 分 | 每个加法段的和就是其中 $1$ 的个数，将各段和高精度相乘；正文代码直接完成，总成本上界 $O(LD)$。 |
| — | 所有数不超过 $9$ | $5\sim6$，$10$ 分 | 单个数小，但多个段相乘仍可能很大；仍用段和乘积与高精度，时间上界 $O(LD)$。 |
| 2 | 只有加号，单个数小于 $10^9$ | $7\sim8$，$10$ 分 | 直接解析并累加，至多 $2500$ 个数，总和小于 $2.5\times10^{12}$，`long long` 足够。时间、含输入串空间均为 $O(L)$。 |
| — | 只有加号，数可很大 | $9\sim10$，$10$ 分 | 只有一个加法段，用正文高精度求和；不应沿用上一行的机器整数，总成本上界 $O(LD)$。 |
| — | 只有乘号 | $11\sim12$，$10$ 分 | 每段只含一个数，按正文高精度连乘，时间上界 $O(LD)$。 |
| — | $L\le1000$ 或完整范围 | $13\sim20$，$40$ 分 | 完整段和乘积算法，时间 $O(LD)$、空间 $O(L+D)$。 |

第 1 项中 $q\le5$，最多十个数字字符形成的运算结果不超过十位数量级，`long long` 足够。第 2 项只用于纯加小数子域，不能用于一般乘法或大数。
