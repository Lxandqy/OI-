# T1 最多求余（maxmod）

---

## 统计频次，按余数升序选答案

---

所有余数都在 $0\sim k-1$，可以直接用数组 `cnt` 统计：读到 $a_i$，就将 $\texttt{cnt}[a_i\bmod k]$ 加一。

再从小到大扫描余数，维护目前出现次数最多的答案。只有当前余数的次数**严格更多**时才更新；次数相同就保留先前较小的余数。扫描结束后同时满足“次数最多”和“并列最小”两个要求。

初始答案取 $0$，扫描 $1\sim k-1$。因此余数为 $0$ 不会遗漏；$k=1$ 时也直接得到唯一答案 $0$。

时间 $O(n+k)$。计数需要 $O(k)$ 空间，交付代码按上界固定开 $100005$ 个整数，约 $0.4$ MiB。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

int cnt[100005];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int n, k;
	cin >> n >> k;
	for(int i = 1; i <= n; i++){
		int x;
		cin >> x;
		cnt[x % k]++;
	}
	int ans = 0;
	// 从小到大扫描；只有次数严格更多时才更新。
	for(int r = 1; r < k; r++){
		if(cnt[r] > cnt[ans]){
			ans = r;
		}
	}
	cout << ans << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分，各点组独立计分；三档均复用完整频次程序。

| 条件 | 点号与分值 | 做法与复杂度 |
|---|---|---|
| 所有余数相同 | $1\sim2$，$20$ 分 | 计数后只有该余数频次非零，升序扫描自然选中它。时间 $O(n+k)$。 |
| 实际出现的余数频次两两不同 | $3\sim6$，$40$ 分 | 最大频次唯一，仍用计数与升序扫描。时间 $O(n+k)$。 |
| 无额外限制 | $7\sim10$，$40$ 分 | 只在次数严格增加时更新，解决并列取小，时间 $O(n+k)$。计数空间 $O(k)$，代码固定数组约 $0.4$ MiB。 |

# T2 各乘一个（crossmul）

---

## 已选个数决定当前乘哪个系数

---

从左到右处理 $a$，当前位置只有选或不选两种决定。若它是选中的第 $j$ 个位置，就必须与 $b_j$ 相乘。后续能选的位置由当前处理范围决定，下一项对应哪个 $b$ 由已选数量决定，因此需要同时记录这两项信息。

令 $dp[i][j]$ 表示在 $a$ 的前 $i$ 个位置中恰好选 $j$ 个，依次与 $b_1,\ldots,b_j$ 配对的最大分数。

若不选 $a_i$，候选为 $dp[i-1][j]$；若选它，它必须是第 $j$ 个被选位置，前面要恰好选 $j-1$ 个，新增 $a_i b_j$。因此

$$dp[i][j]=\max\bigl(dp[i-1][j],\ dp[i-1][j-1]+a_i b_j\bigr),$$

第二项只从可达状态转移。这两种选择覆盖所有方案；只读前 $i-1$ 个位置的状态，也保证同一个位置至多选一次。

初始化 $dp[0][0]=0$，其余 $dp[0][j]$ 为负无穷；每一层的 $dp[i][0]=0$。按 $i$ 递增求表，答案为 $dp[n][x]$。题目允许负数而且要求恰好选满，不能把不可达状态设为 $0$，也不能取所有 $j$ 的最大值。

状态数为 $(n+1)(x+1)$，每格常数次更新，时间、空间均为 $O(nx)$。$x\le10$，表约占 $8.4$ MiB。单项乘积可达 $10^{16}$，总分绝对值至多 $10^{17}$，乘法先转为 `long long`；代码的负无穷小于所有合法总分。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

const long long NEG = -(1LL << 60);
long long dp[100005][11];
int a[100005], b[11];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int n, x;
	cin >> n >> x;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
	}
	for(int j = 1; j <= x; j++){
		cin >> b[j];
		dp[0][j] = NEG;
	}
	// dp[i][j]：前 i 个元素中恰好选 j 个，与 b 的前 j 项配对。
	for(int i = 1; i <= n; i++){
		dp[i][0] = 0;
		for(int j = 1; j <= x; j++){
			dp[i][j] = dp[i - 1][j];
			if(dp[i - 1][j - 1] != NEG){
				long long value = dp[i - 1][j - 1] + 1LL * a[i] * b[j];
				dp[i][j] = max(dp[i][j], value);
			}
		}
	}
	cout << dp[n][x] << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分，各点组独立计分。组合搜索在 $x=1$ 时自然成为线性枚举，前四点联合保证 $40$ 分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n\le20$ | $1\sim2$，$20$ 分 | 递归枚举递增下标，选第 $j$ 个时加入 $a_i b_j$，剪去剩余位置不足的分支，恰好选满再更新。时间上界 $O(n+x\binom nx)$，含输入数组空间 $O(n+x)$。 |
| 复用 1 | $x=1$ | $3\sim4$，$20$ 分 | 搜索仅一层，枚举每个位置的 $a_i b_1$ 并取最大，时间 $O(n)$；负数仍需参与比较。 |
| — | $x=2$ | $5\sim6$，$20$ 分 | DP 只需记录已选 $0,1,2$ 个的前缀最优值，按正文转移，时间、空间 $O(nx)$。 |
| — | $x=3$ | $7\sim8$，$20$ 分 | 同一转移记录已选 $0\sim3$ 个，时间、空间 $O(nx)$。 |
| — | 完整范围 | $9\sim10$，$20$ 分 | 仍是相同前缀 DP，$x\le10$，时间、空间 $O(nx)$。完整代码按最大范围固定开表。 |

# T3 三元组（triples）

---

## 把坐标和的条件拆成两个单点键

---

记 $A=a_i+a_j$、$B=b_i+b_j$。原条件恰好是 $2A\le B$ 或 $2B\le A$。因为 $A,B$ 都为正，两种情况不可能同时成立，否则会推出 $4A\le A$。因此可以分别统计后相加。

第一种写成

$$2(a_i+a_j)\le b_i+b_j
\iff(2a_i-b_i)+(2a_j-b_j)\le0.$$

为每个三元组建立键 $q_i=2a_i-b_i$，权值为 $c_i$，就变成统计键之和不大于零的无序位置对的权值乘积。第二种同理使用 $q_i=2b_i-a_i$。

## 排序后，合法右端点构成前缀

---

将一组键升序排序，权值随键一起移动。固定排序后的左位置 $l$，只考虑右位置 $l\le j\le r$，避免重复统计无序对。因为键有序，能满足 $q_l+q_j\le0$ 的右位置必为连续的一段。

初始化 $r=n$，当 $q_l+q_r>0$ 时将 $r$ 左移。随着 $l$ 增大，$q_l$ 不减，允许的最大 $r$ 只会不增，所以无须重新枚举。若 $r<l$，后面的左位置也不会有合法右位置，可以停止。

令 $prefix[i]$ 为前 $i$ 个权值的和，模 $M=10^9+7$ 保存。本轮贡献为

$$c_l\bigl(prefix[r]-prefix[l-1]\bigr)\bmod M.$$

区间从 $l$ 开始，合法时也包含自对 $(l,l)$；其他位置对只在其较小排序位置被处理一次。排序仅改变编号方式，不改变不同条目或自对的对应关系。两组键的条件互斥，最终两次结果相加即可。

两次排序各 $O(n\log n)$，前缀和与双指针各 $O(n)$，总时间 $O(n\log n)$、空间 $O(n)$。键和使用 `long long`；权值与已取模前缀和的乘积小于约 $10^{18}$，逐次取模不会溢出。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

const long long MOD = 1000000007;
struct Node {
	long long key, weight;
};
Node p[100005];
long long a[100005], b[100005], c[100005], prefix[100005];
int n;

bool cmp(const Node &u, const Node &v){
	return u.key < v.key;
}

long long calc(){
	sort(p + 1, p + n + 1, cmp);
	prefix[0] = 0;
	for(int i = 1; i <= n; i++){
		prefix[i] = (prefix[i - 1] + p[i].weight) % MOD;
	}
	long long result = 0;
	int r = n;
	for(int l = 1; l <= n; l++){
		while(r >= l && p[l].key + p[r].key > 0){
			r--;
		}
		if(r < l){
			break;
		}
		// 区间 [l,r] 包含自身，恰好统计一次无序点对。
		long long sum = (prefix[r] - prefix[l - 1] + MOD) % MOD;
		result = (result + p[l].weight * sum) % MOD;
	}
	return result;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cin >> n;
	for(int i = 1; i <= n; i++){
		cin >> a[i] >> b[i] >> c[i];
		p[i].key = 2 * a[i] - b[i];
		p[i].weight = c[i];
	}
	long long ans = calc();
	for(int i = 1; i <= n; i++){
		p[i].key = 2 * b[i] - a[i];
		p[i].weight = c[i];
	}
	ans = (ans + calc()) % MOD;
	cout << ans << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分，前两组累计保证 $40$ 分；两行复用同一份逐对取模程序。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n\le1000$，总价值小于模数 | $1\sim2$，$20$ 分 | 枚举全部 $i\le j$，直接比较两个坐标和，合法时加入 $c_i c_j$。时间 $O(n^2)$，空间 $O(n)$。 |
| 复用 1 | $n\le1000$ | $3\sim4$，$20$ 分 | 同一枚举，但必须逐次取模；源码两档均取模，不依赖总价值较小。时间 $O(n^2)$，空间 $O(n)$。 |
| — | 完整范围 | $5\sim10$，$60$ 分 | 将条件拆成两组键之和非正，排序后用双指针和权值前缀和计数。时间 $O(n\log n)$，空间 $O(n)$。 |

# T4 切割（splitnum）

---

## 下一段在哪里结束

---

决定下一段时，需要知道从哪一位开始，以及之前各段之和模 $k$ 的余数；已经使用多少切口只影响优劣，不改变后续能作的切割。因此同一位置、同一余数只保留最少切口即可。

按输入顺序把数位放进同一个字符串，另记每一位所属原数的末位 `rightEnd`，确保新段绝不跨越原数。令 $dp[i][r]$ 表示前 $i$ 位已完整分段、段和模 $k$ 为 $r$ 时的最少切口。

从处理完前 $i$ 位的状态出发，下一段由第 $i+1$ 位开始，其末位 $j$ 只能到 $\texttt{rightEnd}[i+1]$。依次扩展 $j$，用

$$value\leftarrow(10\,value+\text{当前数字})\bmod k$$

维护这段的余数。只计算余数既能避免原数达到 $10^{18}$ 时的数值风险，也允许有前导零的数段。

若 $j$ 还没到该原数末尾，需要在其后切一刀，新增成本为 $1$；若恰好到原数末尾，输入本来就已分开，新增成本为 $0$。于是用

$$
dp[j][(r+value)\bmod k]
\leftarrow
\min\bigl(dp[j][(r+value)\bmod k],\ dp[i][r]+cost\bigr)
$$

更新所有可达状态。每个切法有唯一的段末位置序列，都会按这些转移得到；每个内部切口也恰好在前一段结束时计一次。

初始化 $dp[0][0]=0$，其余为无穷大。转移总是到更大的位置，按 $i$ 递增即可。全部 $D$ 位处理完后，只有余数 $0$ 符合要求，输出 $dp[D][0]$；不可达时输出 $-1$。不切割也是合法选择，最优值可以为 $0$。

每个原数至多 $19$ 位，$D\le7600$。代码对每个起点枚举至多 $19$ 个段末，再检查 $k$ 种余数，时间 $O(19Dk)$，空间 $O(Dk)$。固定 DP 数组约占 $12.4$ MiB，最大候选检查数不超过约 $5.8\times10^7$。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

const int INF = 1000000000;
int dp[8005][405], rightEnd[8005];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int n, k;
	cin >> n >> k;
	string s = " ";
	for(int i = 1; i <= n; i++){
		string t;
		cin >> t;
		int start = (int)s.size();
		s += t;
		int finish = (int)s.size() - 1;
		for(int j = start; j <= finish; j++){
			rightEnd[j] = finish;
		}
	}
	int length = (int)s.size() - 1;
	for(int i = 0; i <= length; i++){
		for(int r = 0; r < k; r++){
			dp[i][r] = INF;
		}
	}
	dp[0][0] = 0;
	// dp[i][r]：前 i 位已分段完成，数字和模 k 为 r 的最少切割数。
	for(int i = 0; i < length; i++){
		int value = 0;
		for(int j = i + 1; j <= rightEnd[i + 1]; j++){
			value = (value * 10 + s[j] - '0') % k;
			int cost = 0;
			if(j < rightEnd[i + 1]){
				cost = 1;
			}
			for(int r = 0; r < k; r++){
				if(dp[i][r] == INF){
					continue;
				}
				int next = (r + value) % k;
				dp[j][next] = min(dp[j][next], dp[i][r] + cost);
			}
		}
	}
	if(dp[length][0] == INF){
		cout << -1 << '\n';
	}else{
		cout << dp[length][0] << '\n';
	}
	return 0;
}
```

## 部分分

---

每点 $10$ 分，前两档是累计口径；同一份逐数枚举程序保证前六点，共 $60$ 分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n,k\le10$ | $1\sim2$，$20$ 分 | 对每个原数枚举内部切口掩码，逐位算段和余数，并记录每种余数的最少切口；再将当前数的余数表与此前总余数表合并，保留最小代价。若各数位长为 $d_i$，时间 $O(\sum d_i2^{d_i-1}+nk^2)$。 |
| 复用 1 | $n,k\le100,\ a_i\le10^5$ | $3\sim6$，新增 $40$ 分 | 仍用上述切法枚举与余数合并，此时每个数至多六位。空间 $O(k+\max d_i)$；源码固定余数数组上界为 $405$。 |
| — | 完整范围 | $7\sim10$，$40$ 分 | 按完整分段的数位前缀和余数 DP，枚举下一段末位，时间 $O(19Dk)$、空间 $O(Dk)$。 |

第一档虽可能出现十九位数，但只有 $n\le10$ 个，每数至多 $2^{18}$ 种切法；余数合并无需枚举所有原数切法的笛卡尔积。所有做法都在段内逐位取模，不建立可能溢出的段值。
