# T1 上下五千年（date）

---

## 按时间顺序找第一个回文日期

---

年份、月份和日期直接拼接，不补前导零。按年月日升序检查所有可能的合法日期，首次遇到严格晚于输入的回文日期，就是答案。

代码只枚举每月 $1\sim27$ 日，需要先说明为什么足够。$7010$ 年 $10$ 月 $7$ 日拼成 `7010107`，是回文，且晚于所有合法输入。因此答案不会晚于它，搜索中的年份首位只可能是 $2\sim7$。

回文串末位必须与首位相同，而 $28,29,30,31$ 日的末位分别是 $8,9,0,1$，均不可能。因此这些日期可以全部略过。剩余 $1\sim27$ 日在每个月都合法，无须再处理闰年与大小月。

从输入年份开始，依次枚举月份和 $1\sim27$ 日，先跳过输入当天及以前，再直接拼接三个整数，用首尾向中间比较的方法检查回文。即使输入日期是 $28\sim31$ 日，年月日的比较也会正确跳过同月较早候选。

至多检查 $(7011-y)\times12\times27$ 个日期，不超过约 $163$ 万个；日期字符串长度最多为 $8$，单次检查为常数时间。总时间 $O((7011-y)\times12\times27)$，额外空间 $O(1)$。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

bool palindromeDate(int y,int m,int d){
	string s = to_string(y) + to_string(m) + to_string(d);
	int l = 0,r = (int)s.size() - 1;
	while(l < r){
		if(s[l] != s[r]) return false;
		l++;
		r--;
	}
	return true;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int y,m,d;
	cin >> y >> m >> d;
	for(int yy = y; ; yy++){
		for(int mm = 1; mm <= 12; mm++){
			for(int dd = 1; dd <= 27; dd++){
				if(yy == y && (mm < m || (mm == m && dd <= d))) continue;
				if(palindromeDate(yy,mm,dd)){
					cout << yy << ' ' << mm << ' ' << dd << '\n';
					return 0;
				}
			}
		}
	}
}
```

## 部分分

---

每点 $10$ 分；题面的 $30/60/100$ 分是累计口径。所有档复用上述枚举，无须另设算法。

| 条件 | 点号与累计分值 | 做法与复杂度 |
|---|---|---|
| $2000\le y\le2200$ | $1\sim3$，$30$ 分 | 按年月日顺序检查每月前 $27$ 日，取首次回文；时间上界 $O((7011-y)\times12\times27)$，空间 $O(1)$。 |
| $2000\le y\le4000$ | $1\sim6$，$60$ 分 | 同一枚举覆盖扩大后的年份范围；答案仍不晚于 $7010$ 年 $10$ 月 $7$ 日，复杂度同上。 |
| $2000\le y\le7000$ | $1\sim10$，$100$ 分 | 完整范围仍使用相同上界与回文首尾约束，无须闰年分支，复杂度同上。 |

# T2 采购（purchase）

---

## 净收益作为物品价值，做 0/1 背包

---

每选一件商品，收益中就减少一次 $k$，所以总收益可以写成

$$VAL-k\,COUNT=\sum_{\text{选中的 }i}(val_i-k).$$

把第 $i$ 件的净收益记为 $v_i=val_i-k$，便只需在容量 $m$ 内选择若干件，使净收益之和最大。每件只有一件，属于 0/1 背包；允许空选，所以最优收益至少为 $0$。

决定第 $i$ 件选或不选时，后续只需知道下一件编号与剩余容量，不需要记录已选的具体商品。令 $dp[i][c]$ 表示从第 $i$ 件开始、剩余容量为 $c$ 时，后续能获得的最大净收益。

不选当前件，得到 $dp[i+1][c]$；若 $c\ge w_i$，也可选它，获得 $v_i$，剩余问题为 $dp[i+1][c-w_i]$。因此

$$
dp[i][c]=\max\bigl(dp[i+1][c],\ dp[i+1][c-w_i]+v_i\bigr),
$$

容量不足时忽略第二项。两种选择覆盖所有方案，且都只读取下一件对应的状态，同一件不会重复选择。

没有剩余商品时 $dp[n+1][c]=0$。按 $i=n,n-1,\ldots,1$ 求表，答案是 $dp[1][m]$。净收益为负的商品会被“不选”分支自然排除。

时间 $O(nm)$，至多约三百万个状态；代码保存完整二维表，空间 $O(nm)$，约 $24$ MiB。每件价值不超过 $10^5$，总净收益不超过 $10^8$，代码用 `long long` 保存 DP。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

const int N = 1010;
const int M = 3010;
int n,m,k;
int w[N],value[N];
long long dp[N][M];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cin >> n >> m >> k;
	for(int i = 1; i <= n; i++) cin >> w[i] >> value[i];
	for(int i = n; i >= 1; i--){
		for(int c = 0; c <= m; c++){
			dp[i][c] = dp[i + 1][c];
			if(c >= w[i]){
				dp[i][c] = max(dp[i][c],dp[i + 1][c - w[i]] + value[i] - k);
			}
		}
	}
	cout << dp[1][m] << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分，前两个点组独立计分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n\le20$ | $1\sim2$，$20$ 分 | 每件递归选或不选，维护体积与净收益，超容量即剪枝；合法叶子与空集共同更新答案。时间 $O(2^n)$，空间 $O(n)$。 |
| — | $m\le300$ | $3\sim5$，$30$ 分 | 用正文“下一件、剩余容量”的两种选择转移。有效状态 $O(nm)$；交付满分代码按完整上界固定开表，约 $24$ MiB。 |
| — | 完整范围 | $6\sim10$，$50$ 分 | 同一二维 0/1 背包，时间、空间均为 $O(nm)$，允许空选而无需强取负收益商品。 |

# T3 整除序列（divisible）

---

## 最长链的倍率只能几乎全为二

---

相邻两项严格递增且后项是前项的倍数，所以每一步倍率都是至少为 $2$ 的整数。相邻整除具有传递性，也就满足题目要求的任意前后两项整除。

首项至少为 $L$，长度为 $S$ 时末项至少为 $L2^{S-1}$；从 $L$ 开始不断翻倍，又能达到这个下界。因此从 $1$ 开始维护 $power=2^{S-1}$，在 $2L\,power\le R$ 时继续翻倍，便得到最大长度，并有

$$L2^{S-1}\le R<L2^S.$$

接下来只统计这种最大长度的链。它有 $S-1$ 个倍率：若其中一个达到 $4$，倍率乘积至少为 $2^S$；若有两个达到 $3$，乘积至少为 $9\cdot2^{S-3}>2^S$。这两种情况连最小首项 $L$ 都放不下，所以只剩两类：

- 全部倍率为 $2$，乘积为 $power$。
- 恰好一个倍率为 $3$，其他为 $2$，乘积为 $3\,power/2$，只在 $S\ge2$ 时存在。

固定倍率乘积 $P$，首项可取 $L$ 到 $\lfloor R/P\rfloor$，数量为

$$\max\left(0,\left\lfloor\frac RP\right\rfloor-L+1\right).$$

全二链直接计一次；单三链还可选择三倍出现的 $S-1$ 个位置，所以将对应首项数乘 $S-1$。首项与倍率序列唯一确定整条链，两类也不相交，数量可以相加。

$S=1$ 时没有倍率，只有区间内的单元素链，不能计算含 $power/2$ 的第二项。单问翻倍 $O(\log R)$，计数为 $O(1)$，额外空间 $O(1)$；全部询问为 $O(\sum\log R)$。在 $R\le10^5$ 时 $S\le17$，方案数的粗上界也只有 $SR$，`long long` 可以完整输出。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int T;
	cin >> T;
	while(T--){
		long long L,R;
		cin >> L >> R;
		long long power = 1;
		int len = 1;
		while(L * power * 2 <= R){
			power *= 2;
			len++;
		}
		long long count = max(0LL,R / power - L + 1);
		if(len >= 2){
			long long limit = R / (power / 2 * 3);
			count += (len - 1) * max(0LL,limit - L + 1);
		}
		cout << len << ' ' << count << '\n';
	}
	return 0;
}
```

## 部分分

---

每点 $10$ 分，前两个点组独立计分；两行复用同一份枚举前驱程序，联合保证 $50$ 分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $R-L\le20$ | $1\sim2$，$20$ 分 | 按末项 $x$ 递增，枚举 $L\le y<x$ 且 $y\mid x$，用以 $y$ 结尾的最长链延长一项。更长时覆盖方案数、同长时相加；每个 $x$ 初始为长度 $1$、方案 $1$，最后汇总所有最长终点。时间 $O((R-L+1)^2)$。 |
| 复用 1 | $R\le2000$ | $3\sim5$，$30$ 分 | 沿用上述整除前驱 DP，单问时间 $O((R-L+1)^2)$；源码按数值下标开表，空间 $O(R)$。 |
| — | 完整范围 | $6\sim10$，$50$ 分 | 用翻倍上界确定长度，再计全二链与单三链。单问 $O(\log R)$ 时间、$O(1)$ 额外空间。 |

# T4 绿野仙踪（green）

---

## 二分半径，每次检查覆盖与连通

---

半径增大时，每个花圃覆盖的矩形只会扩大，障碍只增不减。如果某个半径下端点被覆盖或道路已断，更大的半径也一定不可行；可行正半径构成一个前缀。同时覆盖总数不减，因此找到最大可行半径即可。

固定半径 $r$，先将每个正方形裁剪到场内。以中心 $(x_i,y_i)$ 为例，行范围为

$$[\max(0,x_i-r+1),\ \min(n-1,x_i+r-1)],$$

列范围同理。矩形重叠处只计一次，用二维差分求每格被覆盖的次数。对闭矩形 $[x_1,x_2]\times[y_1,y_2]$，四角更新为

$$
\begin{aligned}
d[x_1][y_1]&\mathrel{+}=1,&d[x_2+1][y_1]&\mathrel{-}=1,\\
d[x_1][y_2+1]&\mathrel{-}=1,&d[x_2+1][y_2+1]&\mathrel{+}=1.
\end{aligned}
$$

按行、列递增求二维前缀和，正值格就是花圃并集，同时统计面积。这样每个中心只改四处，不会逐次重复涂色。

若起点或终点被覆盖，直接判失败；否则在未覆盖格中四向 BFS。每个格只入队一次，能到终点就可行。代码的 `state` 中，$0$ 表示尚未访问的空格，$1$ 表示障碍，$2$ 表示已入队，重做判定前清空。

用 $0$ 作可行哨兵，表示没有花圃、面积为 $0$；用 $\max(n,m)+1$ 作不可行哨兵，它会使至少一个花圃覆盖整个场地。二分最后可行值，再重算其覆盖面积。若任何正半径都不可行，最后仍为 $0$，按题意输出 $0$。端点位于对角并不能保证连通，仍须 BFS。

一次判定的差分还原和 BFS 均为 $O(nm)$，矩形更新为 $O(k)$，故总时间 $O((nm+k)\log\max(n,m))$，空间 $O(nm+k)$。网格最多一百万格，队列每次至多保存这么多位置。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

const int N = 1005;
int n,m,k,sx,sy,ex,ey;
int cx[1010],cy[1010],diff[N][N],que[1000010];
unsigned char state[N][N];

void addRect(int x1,int y1,int x2,int y2){
	diff[x1][y1]++;
	diff[x2 + 1][y1]--;
	diff[x1][y2 + 1]--;
	diff[x2 + 1][y2 + 1]++;
}

bool check(int r,int &area){
	area = 0;
	if(r == 0) return true;
	for(int x = 0; x <= n; x++) memset(diff[x],0,(m + 1) * sizeof(int));
	for(int x = 0; x < n; x++) memset(state[x],0,m);
	for(int i = 0; i < k; i++){
		int x1 = max(0,cx[i] - r + 1);
		int x2 = min(n - 1,cx[i] + r - 1);
		int y1 = max(0,cy[i] - r + 1);
		int y2 = min(m - 1,cy[i] + r - 1);
		addRect(x1,y1,x2,y2);
	}
	for(int x = 0; x < n; x++){
		for(int y = 0; y < m; y++){
			if(x > 0) diff[x][y] += diff[x - 1][y];
			if(y > 0) diff[x][y] += diff[x][y - 1];
			if(x > 0 && y > 0) diff[x][y] -= diff[x - 1][y - 1];
			if(diff[x][y] > 0){
				state[x][y] = 1;
				area++;
			}
		}
	}
	if(state[sx][sy] || state[ex][ey]) return false;
	const int dx[4] = {0,1,0,-1};
	const int dy[4] = {1,0,-1,0};
	int head = 0,tail = 0;
	que[tail++] = sx * m + sy;
	state[sx][sy] = 2;
	while(head < tail){
		int id = que[head++];
		int x = id / m;
		int y = id % m;
		if(x == ex && y == ey) return true;
		for(int d = 0; d < 4; d++){
			int nx = x + dx[d];
			int ny = y + dy[d];
			if(nx < 0 || nx >= n || ny < 0 || ny >= m) continue;
			if(state[nx][ny]) continue;
			state[nx][ny] = 2;
			que[tail++] = nx * m + ny;
		}
	}
	return false;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cin >> n >> m >> k;
	cin >> sx >> sy >> ex >> ey;
	for(int i = 0; i < k; i++) cin >> cx[i] >> cy[i];
	int l = 0,r = max(n,m) + 1;
	while(l + 1 < r){
		int mid = (l + r) / 2;
		int area;
		if(check(mid,area)) l = mid;
		else r = mid;
	}
	int area;
	check(l,area);
	cout << area << '\n';
	return 0;
}
```

## 部分分

---

每点 $5$ 分。第 2 项覆盖第 1 项，少中心与相邻端点两个子域合并可保证前八点，共 $40$ 分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n,m\le50,k\le10$ | $1\sim2$，$10$ 分 | 半径从 $1$ 递增，每次逐格涂花圃并 BFS，首次不可行就停止。令 $R=\max(n,m)$，时间粗上界 $O(Rknm)$，空间 $O(nm+k)$。 |
| 2 | $k\le10$ | $1\sim6$，$30$ 分 | 沿用逐格涂色与 BFS，但二分半径，时间粗上界 $O(knm\log R)$，空间 $O(nm+k)$。其中 $k=1$ 的点 $3\sim4$ 自然包含在内。 |
| 3 | 起终点相邻 | $7\sim8$，$10$ 分 | 两格不被覆盖就能一步到达。取所有中心到两个端点的切比雪夫距离的最小值为最大半径，再逐行差分统计并集。时间 $O(n(k+m))$，空间 $O(m+k)$。 |
| — | 起终点为指定对角 | $9\sim10$，$10$ 分 | 障碍仍可能断路，用正文二维差分、BFS 和二分，时间 $O((nm+k)\log R)$。 |
| — | 完整范围 | $11\sim20$，$50$ 分 | 同一一般判定方法，时间 $O((nm+k)\log R)$，空间 $O(nm+k)$。 |

切比雪夫距离为 $\max(\lvert x_1-x_2\rvert,\lvert y_1-y_2\rvert)$；距离为 $d$ 的端点在半径 $r$ 下不被该花圃覆盖，恰好要求 $r\le d$。相邻端点公式不能用于其他位置。
