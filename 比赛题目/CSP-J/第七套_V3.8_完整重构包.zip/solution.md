# T1 回文串（palindrome）

---

## 用相同字符的端点对给答案设上界

---

每个非空回文子串的两端字符必须相同。某字符出现 $c$ 次，以它为两端的子串至多有 $c$ 个单点区间，以及 $\binom c2$ 个不同端点区间，所以这一类最多贡献

$$c+\binom c2=\frac{c(c+1)}2.$$

把相同字符全部连续放在一起，就能达到这个上界：该字符块中任取起终点，中间仍全是这个字符，一定回文。每个字符各放成一块，全部上界同时达到。因此答案就是对 $26$ 个字符的上述贡献求和，无须实际生成排列。

扫描字符串统计频次，再计算 $26$ 项，时间 $O(n+26)$。频次数组占 $O(26)$，但代码还保存整个输入串，所以总空间为 $O(n+26)$。答案最大为 $n(n+1)/2$，可能达到约 $5\times10^{11}$，频次和乘法使用 `long long`。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	string s;
	cin >> s;
	long long cnt[26] = {};
	for(int i = 0; i < (int)s.size(); i++){
		cnt[s[i] - 'a']++;
	}
	long long ans = 0;
	for(int i = 0; i < 26; i++){
		// 将相同字符放在一起，该块贡献 1+2+...+cnt[i]。
		ans += cnt[i] * (cnt[i] + 1) / 2;
	}
	cout << ans << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分；表中保证分按点组计算。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n\le3$ | $1\sim3$，$30$ 分 | 排序后枚举不同排列；每个排列枚举所有非空区间，首尾比较判断回文，统计并取最大。时间上界 $O(n\log n+n!n^3)$，空间 $O(n)$。 |
| — | 完整范围 | $4\sim10$，$70$ 分 | 按相同字符端点对设上界，用同字符连续分块达到上界，统计频次后求 $\sum c(c+1)/2$。时间 $O(n+26)$，完整代码空间 $O(n+26)$。 |

# T2 交错四元组（quad）

---

## 固定中间两个位置，左右分别计数

---

条件 $i<j<k<l$ 且 $a_i<a_k<a_j<a_l$ 中，固定 $j,k$ 后，先要求 $a_k<a_j$。剩余两项互不牵制：

- 左边选 $i<j$ 且 $a_i<a_k$；
- 右边选 $l>k$ 且 $a_l>a_j$。

若两边分别有 $L_{j,k}$ 和 $R_{j,k}$ 个位置，这对中间位置就贡献 $L_{j,k}R_{j,k}$。每个四元组有唯一的 $j,k$，累加不会重复。

左侧数量用表 `leftLess[j][k]` 预处理。固定 $k$，让 $j$ 从 $2$ 增大到 $k-1$，左侧每次仅多出位置 $j-1$，因此

$$
leftLess[j][k]=leftLess[j-1][k]+[a_{j-1}<a_k].
$$

初始表为 $0$。每个 $k$ 扫描一遍，共 $O(n^2)$，不必为每对 $j,k$ 重新统计。

右侧数量不必另开二维表。固定 $j$，让 $k$ 从 $n$ 递减到 $j+1$，用 `rightGreater` 维护当前严格位于 $k$ 右侧、数值大于 $a_j$ 的位置数。先在 $a_k<a_j$ 时加入

$$leftLess[j][k]\times\texttt{rightGreater},$$

再在 $a_k>a_j$ 时将 `rightGreater` 加一，为下一个 $k$ 做准备。先计数后加入当前位置，才能保证第四个位置严格大于 $k$。所有比较均严格，相等元素不会误计。

两部分均为 $O(n^2)$ 时间。保存左侧表，空间 $O(n^2)$；$2005^2$ 个整数约 $15.3$ MiB。答案最多 $\binom n4$，使用 `long long`；代码中右侧计数也是 `long long`，保证乘法先在 $64$ 位中完成。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

int a[2005], leftLess[2005][2005];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
	}
	// leftLess[j][k]：下标小于 j、数值小于 a[k] 的元素数。
	for(int k = 1; k <= n; k++){
		for(int j = 2; j < k; j++){
			leftLess[j][k] = leftLess[j - 1][k];
			if(a[j - 1] < a[k]){
				leftLess[j][k]++;
			}
		}
	}
	long long ans = 0;
	for(int j = 2; j <= n - 2; j++){
		long long rightGreater = 0;
		for(int k = n; k > j; k--){
			if(a[k] < a[j]){
				ans += leftLess[j][k] * rightGreater;
			}
			// 更新放在计数之后，保证第四个位置严格大于 k。
			if(a[k] > a[j]){
				rightGreater++;
			}
		}
	}
	cout << ans << '\n';
	return 0;
}
```

## 部分分

---

每点 $10$ 分；第二项覆盖前五点，累计保证 $50$ 分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n\le20$ | $1\sim2$，$20$ 分 | 四重枚举 $i<j<k<l$，直接检查三个数值严格不等式。时间 $O(n^4)$，空间 $O(n)$。 |
| 2 | $n\le800$ | $1\sim5$，$50$ 分 | 固定 $j$，从右往左预处理每个 $k$ 之后大于 $a_j$ 的数量；再枚举 $i<j<k$，满足 $a_i<a_k<a_j$ 时加上该数量。时间 $O(n^3)$，空间 $O(n)$。 |
| — | 完整范围 | $6\sim10$，$50$ 分 | 预处理左侧计数，并增量维护右侧计数，固定中间对相乘。时间、空间 $O(n^2)$。 |

# T3 文件判定（files）

---

## 八条关系足够逐层核对

---

合法结构只有一个根目录、四个题目目录和四个代码文件，父子关系恰好为 $4+4=8$ 条。关系数不是 $8$，可以立即判 `no`。

先找根：它应当作为父条目出现，却没有任何父亲。枚举所有作为父亲的名称，检查是否出现在任何孩子位置，要求得到的候选名称唯一，并检查它恰好由非空字母段接非空数字段组成。

然后检查根的直接孩子，要求恰好四个、名称全为字母。输入保证没有重复关系、同名表示同一条目，所以这四条根边的孩子互不相同。对每个题目名 `task`，扫描所有关系，要求它恰有一个孩子，而且名称严格等于 `task.cpp`。

这时四条根边与四条文件边已经占满全部八条输入关系。题目名称全为字母，文件名称带 `.cpp`，两层名称不会相同；因此文件不可能再有子条目，也不可能另有环、分离分支或额外目录。反过来，真正合法的结构一定通过以上各项检查，判定充分且必要。

设每组有 $n$ 条关系、最大名称长度为 $L$。代码使用字符串直接比较，时间 $O(n^2L)$、空间 $O(nL)$；本题 $n\le10,L\le20$，无需建立复杂图结构。$t$ 组总时间 $O(\sum n^2L)$。名称大小写敏感，按原字符串比较。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

string a[11], b[11];
int n;

bool isLetter(char c){
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

bool rootNameOK(const string &s){
	int i = 0;
	while(i < (int)s.size() && isLetter(s[i])){
		i++;
	}
	if(i == 0 || i == (int)s.size()){
		return false;
	}
	while(i < (int)s.size()){
		if(s[i] < '0' || s[i] > '9'){
			return false;
		}
		i++;
	}
	return true;
}

bool check(){
	if(n != 8){
		return false;
	}
	string root = "";
	for(int i = 1; i <= n; i++){
		bool hasParent = false;
		for(int j = 1; j <= n; j++){
			if(a[i] == b[j]){
				hasParent = true;
			}
		}
		if(!hasParent){
			if(root != "" && root != a[i]){
				return false;
			}
			root = a[i];
		}
	}
	if(!rootNameOK(root)){
		return false;
	}
	int tasks = 0;
	for(int i = 1; i <= n; i++){
		if(a[i] != root){
			continue;
		}
		tasks++;
		string task = b[i];
		for(int j = 0; j < (int)task.size(); j++){
			if(!isLetter(task[j])){
				return false;
			}
		}
		int files = 0;
		for(int j = 1; j <= n; j++){
			if(a[j] == task){
				files++;
				if(b[j] != task + ".cpp"){
					return false;
				}
			}
		}
		if(files != 1){
			return false;
		}
	}
	// 四条根边 + 四条代码文件边已经占满全部八条关系。
	return tasks == 4;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;
	cin >> t;
	while(t--){
		cin >> n;
		for(int i = 1; i <= n; i++){
			cin >> a[i] >> b[i];
		}
		if(check()){
			cout << "yes\n";
		}else{
			cout << "no\n";
		}
	}
	return 0;
}
```

## 部分分

---

每点 $10$ 分，各点组独立计分。$n\le10$，完整核对本身足够简单，各档复用同一份源码。

| 条件 | 点号与分值 | 做法与复杂度 |
|---|---|---|
| 性质 1、2、3 | $1\sim2$，$20$ 分 | 已保证名称、唯一根及三级结构，仍需核对是否恰有四个题目及各自唯一文件。完整八关系核验直接覆盖。 |
| 性质 1、3 | $3\sim4$，$20$ 分 | 继续检查题目纯字母名称、文件名对应和四题数量。完整检查时间 $O(n^2L)$。 |
| 性质 2 | $5\sim6$，$20$ 分 | 名称已符合要求，但仍需检查根的唯一性、四题结构及恰好八条关系，时间 $O(n^2L)$。 |
| 无额外性质 | $7\sim10$，$40$ 分 | 完整检查关系数、根名称与两层孩子，时间 $O(n^2L)$、空间 $O(nL)$，$L$ 为名称最大长度。 |

# T4 树与叶子（leafcut）

---

## 先数原叶子，只修正删边的两个端点

---

删去边 $(u,v)$ 后，只有 $u,v$ 的度数各减一，其他点的叶子身份不变。原度为 $1$ 的端点变成孤点，题目仍把它算作叶子，所以不应扣掉；原度为 $2$ 的端点变成度 $1$，本侧新增一个叶子；更大的度数不会变成叶子。

设原叶子总数为 $total$，删边后 $u$ 侧原有叶子数为 $x$，两侧的新叶子数便是

$$
L_1=x+[deg(u)=2],\qquad
L_2=total-x+[deg(v)=2].
$$

关键只剩怎样一次求出每条边一侧的原叶子数。可以从树叶向内逐步合并：每个原叶子带权 $1$，其他点带权 $0$；把当前只剩一个邻居的点 $u$ 所代表的整块并入邻居 $v$，并将累计权值传给 $v$。

这里剥离只用于统计，不能用剥离后的度数判断题目中的叶子。保留原度 `degreeOld`，另用 `degreeNow` 记录尚未合并的连接数；`leaf[u]` 是已经合并到 $u$ 这一块中的原叶子总数。

当 $u$ 当前只剩邻居 $v$ 时，所有其他方向都已归入 $u$，所以 `leaf[u]` 恰好就是原树删去 $(u,v)$ 后 $u$ 侧的原叶子数。此时用公式比较叶子数差，再将 `leaf[u]` 加入 `leaf[v]`，删除当前连接；若 $v$ 的当前度数降为 $1$，将它入队。

树不断去掉叶侧后仍连通，直到只剩一个点，因此每条边恰好在其一侧被合并时计算一次。队列中可能已有度数变成 $0$ 的点，跳过即可，避免重复处理最后一条边。维护最小差与达到该差的边数：更小时重置为 $1$，相等时加一。

每个点至多在成为当前叶子时入队，查找剩余邻居的扫描总量不超过邻接表长度 $2(n-1)$，故单棵树时间 $O(n)$、空间 $O(n)$；多组总时间 $O(\sum n)$。$n=2$ 时两侧都是孤点，公式仍分别得到一个叶子，无须额外处理。

### 满分参考代码

```cpp
#include<bits/stdc++.h>
using namespace std;

const int N = 100000 + 10;
vector<int> g[N];
int degreeNow[N],degreeOld[N],leaf[N],que[N];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int T;
	cin >> T;
	while(T--){
		int n;
		cin >> n;
		for(int i = 1; i <= n; i++){
			g[i].clear();
			degreeNow[i] = 0;
			leaf[i] = 0;
		}
		for(int i = 1; i < n; i++){
			int u,v;
			cin >> u >> v;
			g[u].push_back(v);
			g[v].push_back(u);
			degreeNow[u]++;
			degreeNow[v]++;
		}
		int total = 0,head = 0,tail = 0;
		for(int i = 1; i <= n; i++){
			degreeOld[i] = degreeNow[i];
			if(degreeNow[i] == 1){
				leaf[i] = 1;
				total++;
				que[tail++] = i;
			}
		}
		int ans = n,ways = 0;
		while(head < tail){
			int u = que[head++];
			if(degreeNow[u] != 1) continue;
			int v = 0;
			for(int j = 0; j < (int)g[u].size(); j++){
				int x = g[u][j];
				if(degreeNow[x] > 0){
					v = x;
					break;
				}
			}
			if(v == 0) continue;
			int left = leaf[u] + (degreeOld[u] == 2);
			int right = total - leaf[u] + (degreeOld[v] == 2);
			int delta = abs(left - right);
			if(delta < ans){
				ans = delta;
				ways = 1;
			}else if(delta == ans){
				ways++;
			}
			leaf[v] += leaf[u];
			degreeNow[u] = 0;
			degreeNow[v]--;
			if(degreeNow[v] == 1) que[tail++] = v;
		}
		cout << ans << ' ' << ways << '\n';
	}
	return 0;
}
```

## 部分分

---

每点 $10$ 分；前两个规模档累计 $20$ 分，链形另占 $10$ 分。

| 序号 | 条件 | 点号与保证分 | 做法与复杂度 |
|---:|---|---|---|
| 1 | $n\le100$ 或 $n\le1000$ | $1\sim2$，累计 $20$ 分 | 枚举禁止通行的边，从两端分别 BFS，按删边后度数不超过 $1$ 统计叶子，比较差值。单棵一般树时间 $O(n^2)$，空间 $O(n)$。 |
| 复用 1 | 树是一条链 | $3$，$10$ 分 | 同一源码先判链：$n=2$ 输出 $(0,1)$，$n=3$ 输出 $(1,2)$；$n\ge4$ 时，删内部边使两边各有两个叶子，共 $n-3$ 条。时间、空间 $O(n)$。 |
| — | 最优断边只有一条 | $4$，$10$ 分 | 唯一性没有给出边的位置，仍用正文线性算法检查全部边，计数最终为 $1$。时间、空间 $O(n)$。 |
| — | 完整范围 | $5\sim10$，$60$ 分 | 从叶向内汇总原叶子数，并修正原度为 $2$ 的端点，单棵时间、空间均为 $O(n)$。 |

第 1 份源码组合了判链公式与一般树的逐边 BFS，保证前三点共 $30$ 分。多组数据的时间按各棵树的成本求和。
